create
    definer = root@`%` procedure add_data(IN n int)
BEGIN
    DECLARE i INT UNSIGNED DEFAULT 0;
    WHILE i < n DO
        INSERT INTO `user_memory`(username,create_time) 
        VALUES (rand_string(15),now());
        SET i = i+1;
    END WHILE;
END;

